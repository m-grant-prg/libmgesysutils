var searchData=
[
  ['validatekeyvalue_69',['validatekeyvalue',['../configfile_8c.html#a82cca0ba6d17706187a500f9831bd7c9',1,'configfile.c']]],
  ['validatesection_70',['validatesection',['../configfile_8c.html#a807a8f9f6d8eec54d847c74f27d2f879',1,'configfile.c']]]
];
