var searchData=
[
  ['mge_2dconfigfile_2eh_53',['mge-configfile.h',['../mge-configfile_8h.html',1,'']]],
  ['mge_2dremsyslog_2eh_54',['mge-remsyslog.h',['../mge-remsyslog_8h.html',1,'']]]
];
