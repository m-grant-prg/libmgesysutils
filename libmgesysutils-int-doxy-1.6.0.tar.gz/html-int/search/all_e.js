var searchData=
[
  ['validatekeyvalue_41',['validatekeyvalue',['../configfile_8c.html#a4d7e714283e0f9f58e37b183ee3563a7',1,'configfile.c']]],
  ['validatesection_42',['validatesection',['../configfile_8c.html#aedd0707414a06dd8f80f9ce9208d92e4',1,'configfile.c']]],
  ['value_43',['value',['../structconfkey.html#a2dea8074569e66cce8419ab0b5f3f884',1,'confkey']]],
  ['version_2ec_44',['version.c',['../version_8c.html',1,'']]]
];
