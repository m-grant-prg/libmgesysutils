var mge_configfile_8h =
[
    [ "confkey", "structconfkey.html", "structconfkey" ],
    [ "confsection", "structconfsection.html", "structconfsection" ],
    [ "MAX_KEYS_PER_SECTION", "mge-configfile_8h.html#a2ae783b8fbfa14e8e793794c2eaf3563", null ],
    [ "MAX_KEYVAL_LENGTH", "mge-configfile_8h.html#a7f7d3a220880b3e8c114a91011b22e5e", null ],
    [ "MAX_LINE_LENGTH", "mge-configfile_8h.html#af0f2173e3b202ddf5756531b4471dcb2", null ],
    [ "parsefile", "mge-configfile_8h.html#abc2029827f55a75bda15580fc9ac7ddc", null ]
];