var searchData=
[
  ['validatekeyvalue_67',['validatekeyvalue',['../configfile_8c.html#a4d7e714283e0f9f58e37b183ee3563a7',1,'configfile.c']]],
  ['validatesection_68',['validatesection',['../configfile_8c.html#aedd0707414a06dd8f80f9ce9208d92e4',1,'configfile.c']]]
];
