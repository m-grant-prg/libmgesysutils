var searchData=
[
  ['remote_20syslog_34',['Remote SysLog',['../md_docs_doxygen_src_300_remsyslog.html',1,'']]],
  ['remsyslog_2ec_35',['remsyslog.c',['../remsyslog_8c.html',1,'']]]
];
