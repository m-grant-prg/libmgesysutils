var searchData=
[
  ['remsyslog_2ec_51',['remsyslog.c',['../remsyslog_8c.html',1,'']]],
  ['remsyslog_2eh_52',['remsyslog.h',['../remsyslog_8h.html',1,'']]]
];
