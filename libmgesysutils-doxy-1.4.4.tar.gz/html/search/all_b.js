var searchData=
[
  ['remote_20syslog_34',['Remote SysLog',['../md_docs_doxygen_src_300-remsyslog.html',1,'']]],
  ['remsyslog_2ec_35',['remsyslog.c',['../remsyslog_8c.html',1,'']]],
  ['remsyslog_2eh_36',['remsyslog.h',['../remsyslog_8h.html',1,'']]]
];
