var searchData=
[
  ['isolatekey_58',['isolatekey',['../configfile_8c.html#a14a82a9d867dd0e6a7abdb351dd5f235',1,'configfile.c']]],
  ['isolatevalue_59',['isolatevalue',['../configfile_8c.html#a5a20c9fd0b24712126586217ef20f317',1,'configfile.c']]]
];
