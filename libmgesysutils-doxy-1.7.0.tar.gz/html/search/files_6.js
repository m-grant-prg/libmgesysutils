var searchData=
[
  ['remsyslog_2ec_51',['remsyslog.c',['../remsyslog_8c.html',1,'']]]
];
