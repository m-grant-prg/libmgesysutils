var structconfsection =
[
    [ "keys", "structconfsection.html#a36676c56cd4ec3ed20a3e4d15b19a1e5", null ],
    [ "mandatory", "structconfsection.html#a8d711981de9206d0cd6601a4b8d6907f", null ],
    [ "present", "structconfsection.html#a0ece58bcf125edef002fd8cc75f8d6da", null ],
    [ "section", "structconfsection.html#a6a4f19e932bc4c92841653e974164301", null ]
];