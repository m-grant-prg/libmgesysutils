var remsyslog_8c =
[
    [ "sndremsyslogmsg", "remsyslog_8c.html#a59fc3adebab8873944a459ee0ebabe15", null ]
];