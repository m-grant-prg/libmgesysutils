var searchData=
[
  ['sndremsyslogmsg_69',['sndremsyslogmsg',['../mge-remsyslog_8h.html#ac2466c88642bbf09e42d9abd7f3d6c21',1,'sndremsyslogmsg(const char *hostname, const char *prog_name, const char *message):&#160;remsyslog.c'],['../remsyslog_8c.html#a59fc3adebab8873944a459ee0ebabe15',1,'sndremsyslogmsg(const char *hostname, const char *prog_name, const char *message):&#160;remsyslog.c']]]
];
