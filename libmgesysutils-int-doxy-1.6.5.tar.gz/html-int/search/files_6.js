var searchData=
[
  ['remsyslog_2ec_54',['remsyslog.c',['../remsyslog_8c.html',1,'']]]
];
