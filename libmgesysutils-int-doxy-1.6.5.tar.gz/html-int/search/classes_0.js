var searchData=
[
  ['confkey_44',['confkey',['../structconfkey.html',1,'']]],
  ['confsection_45',['confsection',['../structconfsection.html',1,'']]]
];
