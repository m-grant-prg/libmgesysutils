var annotated_dup =
[
    [ "confkey", "structconfkey.html", "structconfkey" ],
    [ "confsection", "structconfsection.html", "structconfsection" ]
];