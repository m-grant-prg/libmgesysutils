var searchData=
[
  ['confkey_43',['confkey',['../structconfkey.html',1,'']]],
  ['confsection_44',['confsection',['../structconfsection.html',1,'']]]
];
