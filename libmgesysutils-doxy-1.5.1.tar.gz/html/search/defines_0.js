var searchData=
[
  ['max_5fkeys_5fper_5fsection_80',['MAX_KEYS_PER_SECTION',['../mge-configfile_8h.html#a2ae783b8fbfa14e8e793794c2eaf3563',1,'mge-configfile.h']]],
  ['max_5fkeyval_5flength_81',['MAX_KEYVAL_LENGTH',['../mge-configfile_8h.html#a7f7d3a220880b3e8c114a91011b22e5e',1,'mge-configfile.h']]],
  ['max_5fline_5flength_82',['MAX_LINE_LENGTH',['../mge-configfile_8h.html#af0f2173e3b202ddf5756531b4471dcb2',1,'mge-configfile.h']]]
];
