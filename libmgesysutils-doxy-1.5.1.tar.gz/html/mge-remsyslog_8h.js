var mge_remsyslog_8h =
[
    [ "sndremsyslogmsg", "mge-remsyslog_8h.html#ac2466c88642bbf09e42d9abd7f3d6c21", null ]
];