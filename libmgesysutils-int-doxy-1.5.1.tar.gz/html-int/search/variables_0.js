var searchData=
[
  ['currentsection_74',['currentsection',['../configfile_8c.html#a5a9c4c2a189515d9308a5a226f393bce',1,'configfile.c']]]
];
