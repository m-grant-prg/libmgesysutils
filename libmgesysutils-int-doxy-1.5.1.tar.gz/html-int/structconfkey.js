var structconfkey =
[
    [ "key", "structconfkey.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "mandatory", "structconfkey.html#a8d711981de9206d0cd6601a4b8d6907f", null ],
    [ "present", "structconfkey.html#a0ece58bcf125edef002fd8cc75f8d6da", null ],
    [ "value", "structconfkey.html#a2dea8074569e66cce8419ab0b5f3f884", null ]
];