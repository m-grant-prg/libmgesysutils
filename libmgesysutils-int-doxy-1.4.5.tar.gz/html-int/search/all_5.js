var searchData=
[
  ['internal_2eh_13',['internal.h',['../internal_8h.html',1,'']]],
  ['isolatekey_14',['isolatekey',['../configfile_8c.html#a14a82a9d867dd0e6a7abdb351dd5f235',1,'isolatekey(char *pline, char *endkey, char *key):&#160;configfile.c'],['../internal_8h.html#a653baa8cc9a9a671eeb5d27288c0fe86',1,'isolatekey(char *, char *, char *):&#160;internal.h']]],
  ['isolatevalue_15',['isolatevalue',['../configfile_8c.html#a5a20c9fd0b24712126586217ef20f317',1,'isolatevalue(char *startvalue, char *endvalue, char *value):&#160;configfile.c'],['../internal_8h.html#aec3d553ef84aba5d0e59abef1cd9d0e9',1,'isolatevalue(char *, char *, char *):&#160;internal.h']]]
];
