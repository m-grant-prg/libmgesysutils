var searchData=
[
  ['_5f_5fattribute_5f_5f_4',['__attribute__',['../libmgesysutils_8h.html#a6e9028bef6f664bcf63f8ff7e782a807',1,'__attribute__((const)) const char *libmgesysutils_get_pkg_version(void):&#160;version.c'],['../version_8c.html#a699f6a3da91f9155d09cd12158ed6def',1,'__attribute__((const)) const:&#160;version.c']]]
];
