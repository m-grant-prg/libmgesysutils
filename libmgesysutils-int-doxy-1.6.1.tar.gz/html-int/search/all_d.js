var searchData=
[
  ['remote_20syslog_36',['Remote SysLog',['../md_docs_doxygen_src_300_remsyslog.html',1,'']]],
  ['remsyslog_2ec_37',['remsyslog.c',['../remsyslog_8c.html',1,'']]]
];
