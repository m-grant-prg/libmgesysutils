var searchData=
[
  ['remsyslog_2ec_52',['remsyslog.c',['../remsyslog_8c.html',1,'']]]
];
