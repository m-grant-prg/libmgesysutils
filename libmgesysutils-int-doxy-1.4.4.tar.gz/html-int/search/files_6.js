var searchData=
[
  ['remsyslog_2ec_53',['remsyslog.c',['../remsyslog_8c.html',1,'']]],
  ['remsyslog_2eh_54',['remsyslog.h',['../remsyslog_8h.html',1,'']]]
];
