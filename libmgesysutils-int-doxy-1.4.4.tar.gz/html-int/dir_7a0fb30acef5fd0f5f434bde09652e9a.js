var dir_7a0fb30acef5fd0f5f434bde09652e9a =
[
    [ "configfile.c", "configfile_8c.html", "configfile_8c" ],
    [ "internal.h", "internal_8h.html", "internal_8h" ]
];