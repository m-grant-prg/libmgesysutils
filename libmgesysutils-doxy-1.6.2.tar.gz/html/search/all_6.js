var searchData=
[
  ['isolatekey_13',['isolatekey',['../configfile_8c.html#a653baa8cc9a9a671eeb5d27288c0fe86',1,'configfile.c']]],
  ['isolatevalue_14',['isolatevalue',['../configfile_8c.html#aec3d553ef84aba5d0e59abef1cd9d0e9',1,'configfile.c']]]
];
