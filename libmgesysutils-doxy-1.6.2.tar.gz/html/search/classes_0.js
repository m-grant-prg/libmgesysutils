var searchData=
[
  ['confkey_42',['confkey',['../structconfkey.html',1,'']]],
  ['confsection_43',['confsection',['../structconfsection.html',1,'']]]
];
