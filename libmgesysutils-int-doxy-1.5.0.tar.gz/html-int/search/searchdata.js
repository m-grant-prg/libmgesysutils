var indexSectionsWithContent =
{
  0: "123acgiklmoprsv",
  1: "c",
  2: "123clmrv",
  3: "cgilpsv",
  4: "cklmpsv",
  5: "m",
  6: "acor"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Pages"
};

