var searchData=
[
  ['confkey_45',['confkey',['../structconfkey.html',1,'']]],
  ['confsection_46',['confsection',['../structconfsection.html',1,'']]]
];
