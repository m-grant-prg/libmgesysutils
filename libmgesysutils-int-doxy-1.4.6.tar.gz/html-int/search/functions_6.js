var searchData=
[
  ['validatekeyvalue_71',['validatekeyvalue',['../configfile_8c.html#a82cca0ba6d17706187a500f9831bd7c9',1,'validatekeyvalue(char *key, char *value):&#160;configfile.c'],['../internal_8h.html#a4d7e714283e0f9f58e37b183ee3563a7',1,'validatekeyvalue(char *, char *):&#160;internal.h']]],
  ['validatesection_72',['validatesection',['../configfile_8c.html#a807a8f9f6d8eec54d847c74f27d2f879',1,'validatesection(struct confsection *params, int nparams, char *section):&#160;configfile.c'],['../internal_8h.html#aedd0707414a06dd8f80f9ce9208d92e4',1,'validatesection(struct confsection *, int, char *):&#160;internal.h']]]
];
