var searchData=
[
  ['mge_2dconfigfile_2eh_49',['mge-configfile.h',['../mge-configfile_8h.html',1,'']]],
  ['mge_2dremsyslog_2eh_50',['mge-remsyslog.h',['../mge-remsyslog_8h.html',1,'']]]
];
