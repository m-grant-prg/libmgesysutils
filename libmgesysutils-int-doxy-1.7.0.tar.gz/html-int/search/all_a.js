var searchData=
[
  ['mandatory_23',['mandatory',['../structconfkey.html#a8d711981de9206d0cd6601a4b8d6907f',1,'confkey::mandatory()'],['../structconfsection.html#a8d711981de9206d0cd6601a4b8d6907f',1,'confsection::mandatory()']]],
  ['max_5fkeys_5fper_5fsection_24',['MAX_KEYS_PER_SECTION',['../mge-configfile_8h.html#a2ae783b8fbfa14e8e793794c2eaf3563',1,'mge-configfile.h']]],
  ['max_5fkeyval_5flength_25',['MAX_KEYVAL_LENGTH',['../mge-configfile_8h.html#a7f7d3a220880b3e8c114a91011b22e5e',1,'mge-configfile.h']]],
  ['max_5fline_5flength_26',['MAX_LINE_LENGTH',['../mge-configfile_8h.html#af0f2173e3b202ddf5756531b4471dcb2',1,'mge-configfile.h']]],
  ['mge_2dconfigfile_2eh_27',['mge-configfile.h',['../mge-configfile_8h.html',1,'']]],
  ['mge_2dremsyslog_2eh_28',['mge-remsyslog.h',['../mge-remsyslog_8h.html',1,'']]]
];
