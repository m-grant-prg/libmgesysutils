var searchData=
[
  ['validatekeyvalue_40',['validatekeyvalue',['../configfile_8c.html#a82cca0ba6d17706187a500f9831bd7c9',1,'configfile.c']]],
  ['validatesection_41',['validatesection',['../configfile_8c.html#a807a8f9f6d8eec54d847c74f27d2f879',1,'configfile.c']]],
  ['value_42',['value',['../structconfkey.html#a2dea8074569e66cce8419ab0b5f3f884',1,'confkey']]],
  ['version_2ec_43',['version.c',['../version_8c.html',1,'']]]
];
