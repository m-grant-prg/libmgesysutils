var dir_6d9d64069ca2589f604ef7b0ef39e83d =
[
    [ "libmgesysutils.h", "libmgesysutils_8h.html", "libmgesysutils_8h" ],
    [ "mge-configfile.h", "mge-configfile_8h.html", "mge-configfile_8h" ],
    [ "mge-remsyslog.h", "mge-remsyslog_8h.html", "mge-remsyslog_8h" ]
];